﻿using System;
using System.Text;

namespace NPL.M.A003.Exercise1
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Program prg = new Program();
            long decimalNumber;

            while (true)
            {
                Console.Write("Input decimal Number: ");
                if (long.TryParse(Console.ReadLine(), out decimalNumber))
                {
                    break;
                }
            }

            var binaryNumber = prg.ConvertToBinary(decimalNumber);
            Console.WriteLine($"Output binary number: {binaryNumber}");

            Console.ReadKey();
        }
        private StringBuilder ConvertToBinary(long decimalNumber)
        {

            StringBuilder result = new StringBuilder();


            while (decimalNumber != 0)
            {
                // Chia lay du va cong vao chuoi binary
                result.Insert(0, (decimalNumber % 2).ToString(), 1);

                decimalNumber = decimalNumber / 2;

            }

            return result;
        }
    }
}
